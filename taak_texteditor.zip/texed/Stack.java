package texed;

public interface Stack<T> {

}
